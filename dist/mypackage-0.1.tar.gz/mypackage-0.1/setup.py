# -*- coding: utf-8 -*-
"""
Created on Mon Feb 22 15:29:08 2021

@author: hp
"""

from distutils.core import setup
setup(
  name = 'mypackage',
  packages = ['mypackage'], # this must be the same as the name above
  version = '0.1',
  description = 'paquete de prueba',
  author = 'Nilda G.Xolo  Tlapanco',
  author_email = 'nilda_gaby_9745@live.com.mx',
  url = 'https://github.com/NildaX/mypackage', # use the URL to the github repo
  license='MIT',
  keywords = ['testing', 'IFS', 'example'],
  classifiers = ['Programming Language :: Python :: 3.4'], 
  )