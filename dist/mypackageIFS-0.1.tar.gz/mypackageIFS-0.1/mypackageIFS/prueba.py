# -*- coding: utf-8 -*-
"""
Created on Fri Feb 26 22:07:49 2021

@author: hp
"""
from prueba_ifs import *
if __name__ == "__main__": 
    print("tambien corre esto")
    ifs = prueba_ifs()
    ifs.imprimir()
  #  (ifs.window).mainloop()